# Outline Shader for Unity
Unity 2018.3 project source for completed [Outline Shader Tutorial](https://roystan.net/articles/outline-shader.html) from the site [roystan.net](https://roystan.net/).

![alt text](https://i.imgur.com/wWU7Q6d.png)

Uses the depth and normals buffers to generate outlines of variable thickness and color.
